import { useEffect, useState } from "react";

import api from "../services/api";

import Navbar from "../components/Navbar";

export default function Dashboard() {

    const [tasks, setTasks] = useState([]);

    const [title, setTitle] = useState("");

    const [description, setDescription] = useState("");

    async function loadTasks() {

        const res = await api.get("/tasks/");

        setTasks(res.data.data);

    }

    useEffect(() => {

        loadTasks();

    }, []);

    async function createTask(e) {

        e.preventDefault();

        await api.post("/tasks/", {

            title,

            description

        });

        setTitle("");

        setDescription("");

        loadTasks();

    }

    async function deleteTask(id) {

        await api.delete(`/tasks/${id}`);

        loadTasks();

    }

    async function toggleComplete(task) {

        await api.put(`/tasks/${task._id}`, {

            completed: !task.completed

        });

        loadTasks();

    }

    return (

        <>

            <Navbar />

            <div className="dashboard">

                <form
                    className="task-form"
                    onSubmit={createTask}
                >

                    <h3>Create Task</h3>

                    <input

                        placeholder="Title"

                        value={title}

                        onChange={(e)=>setTitle(e.target.value)}

                    />

                    <textarea

                        placeholder="Description"

                        value={description}

                        onChange={(e)=>setDescription(e.target.value)}

                    />

                    <button>

                        Add Task

                    </button>

                </form>

                <div className="tasks">

                    {

                        tasks.map(task=>(

                            <div
                                key={task._id}
                                className="task-card"
                            >

                                <h3>

                                    {task.title}

                                </h3>

                                <p>

                                    {task.description}

                                </p>

                                <p>

                                    {

                                        task.completed

                                        ?

                                        "✅ Completed"

                                        :

                                        "⏳ Pending"

                                    }

                                </p>

                                <button

                                    onClick={()=>toggleComplete(task)}

                                >

                                    Toggle

                                </button>

                                <button

                                    onClick={()=>deleteTask(task._id)}

                                >

                                    Delete

                                </button>

                            </div>

                        ))

                    }

                </div>

            </div>

        </>

    );

}