import { useNavigate } from "react-router-dom";

export default function Navbar() {

    const navigate = useNavigate();

    function logout() {

        localStorage.clear();

        navigate("/");

        window.location.reload();

    }

    return (

        <nav className="navbar">

            <h2>Task Manager</h2>

            <button onClick={logout}>

                Logout

            </button>

        </nav>

    );

}